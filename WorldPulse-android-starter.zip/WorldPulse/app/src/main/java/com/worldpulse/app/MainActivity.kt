package com.worldpulse.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.worldpulse.app.ui.theme.WorldPulseTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WorldPulseTheme { WorldPulseApp() } }
    }
}

private val Navy = Color(0xFF07111F)
private val Card = Color(0xFF101E30)
private val Blue = Color(0xFF4EA1FF)

@Composable
fun WorldPulseApp() {
    var selected by remember { mutableIntStateOf(0) }
    val items = listOf("Home", "Explore", "Map", "Saved", "Profile")
    Scaffold(
        containerColor = Navy,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0A1727)) {
                items.forEachIndexed { index, label ->
                    val icon = when(index) { 0 -> Icons.Default.Home; 1 -> Icons.Default.Search; 2 -> Icons.Default.Public; 3 -> Icons.Default.Bookmark; else -> Icons.Default.Person }
                    NavigationBarItem(selected = selected == index, onClick = { selected = index }, icon = { Icon(icon, null) }, label = { Text(label) })
                }
            }
        }
    ) { pad ->
        when(selected) {
            0 -> HomeScreen(Modifier.padding(pad))
            1 -> SimpleScreen("Explore", "Browse the world by topic and region.", Modifier.padding(pad))
            2 -> SimpleScreen("World Map", "Major events will appear here by location.", Modifier.padding(pad))
            3 -> SimpleScreen("Saved", "Your bookmarked stories will live here.", Modifier.padding(pad))
            else -> ProfileScreen(Modifier.padding(pad))
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(horizontal = 18.dp).verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(22.dp))
        Text("WORLD PULSE", color = Blue, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        Text("What's happening?", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Surface(color = Card, shape = RoundedCornerShape(16.dp)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = Blue)
                Spacer(Modifier.width(10.dp))
                Column { Text("Tanzania", color = Color.White, fontWeight = FontWeight.SemiBold); Text("East Africa • Africa • World", color = Color.LightGray) }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("LIVE / DEVELOPING", color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        StoryCard("🌍", "World", "Your live global briefing will appear here.", "Ready for news feeds")
        StoryCard("🇹🇿", "Tanzania", "Local and regional stories will be prioritized for you.", "Location-aware")
        StoryCard("🔬", "Science & Technology", "AI, space, discoveries and major technology developments.", "Coming next")
        Spacer(Modifier.height(12.dp))
        Text("TOPICS", color = Color.White, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Politics", "Security", "Religion", "Science", "Environment", "Sports").forEach { topic -> AssistChip(onClick = {}, label = { Text(topic) }) }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun StoryCard(emoji: String, title: String, body: String, tag: String) {
    Surface(color = Card, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(emoji, style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.width(10.dp)); Text(title, color = Blue, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f)); Text(tag, color = Color.Gray, style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.height(8.dp)); Text(body, color = Color.White, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
fun SimpleScreen(title: String, body: String, modifier: Modifier) {
    Box(modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(title, color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(body, color = Color.LightGray) }
    }
}

@Composable
fun ProfileScreen(modifier: Modifier) {
    var language by remember { mutableStateOf("English") }
    Column(modifier.fillMaxSize().padding(24.dp)) {
        Text("Profile & Settings", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp)); Text("Language", color = Color.LightGray); Spacer(Modifier.height(8.dp))
        listOf("English", "Kiswahili", "Español", "Français", "中文").forEach { lang ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = language == lang, onClick = { language = lang }); Text(lang, color = Color.White)
            }
        }
    }
}
