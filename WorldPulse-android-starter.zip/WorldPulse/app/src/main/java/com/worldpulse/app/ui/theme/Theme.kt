package com.worldpulse.app.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4EA1FF),
    secondary = Color(0xFF8ABFFF),
    background = Color(0xFF07111F),
    surface = Color(0xFF101E30),
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun WorldPulseTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
