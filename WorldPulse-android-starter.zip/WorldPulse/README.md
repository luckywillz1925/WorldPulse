# World Pulse — Android starter

World Pulse is a multilingual global-awareness app concept: Tanzania → East Africa → Africa → World, with breaking/developing stories, explainers, sources, maps and topic feeds.

## Current prototype
- Jetpack Compose Android UI
- Dark global-dashboard visual style
- Home / Explore / Map / Saved / Profile navigation
- Tanzania → East Africa → Africa → World location framing
- Topic chips
- Language selector: English, Kiswahili, Español, Français, 中文

## Next build stages
1. Real news/data APIs and source attribution
2. Multilingual content pipeline
3. World event map
4. Search, filters, saved stories and notifications
5. Personalization and regional feeds
6. Accessibility and age-appropriate presentation
7. Testing and release signing
8. Google Play Store listing and publishing
