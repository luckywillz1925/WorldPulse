# World Pulse — PWA starter

This is the phone-friendly first version of World Pulse.

It is currently a front-end prototype: the live news/event data source is NOT connected yet.

To make it installable as a PWA, it needs to be hosted over HTTPS. The next development stage is to connect a backend/news source, add real language switching, user settings, notifications, maps, and source verification.

Do not treat the placeholder stories as real news.
